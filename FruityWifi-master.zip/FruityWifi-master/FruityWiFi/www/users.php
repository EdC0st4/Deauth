<? 
/*
	Copyright (C) 2013  xtr4nge [_AT_] gmail.com

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/ 
?>
<?
//admin:admin (reset value: 21232f297a57a5a743894a0e4a801fc3)
//$users["admin"] = "e0af4165b46fb55924f5f9d43ac35f7c"; //test.123456
$users["admin"]="21232f297a57a5a743894a0e4a801fc3"; //admin (reset: 21232f297a57a5a743894a0e4a801fc3)
?>
